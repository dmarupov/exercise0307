package p7.form_template_method2.org;

public abstract class SuperClass {
   public static final double TAX_RATE = 3;
   
   public abstract double compute (double i, double j);
}
